    
<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="panel.php">
                          <i class="fa fa-dashboard"></i> Panel
                       <!-- <img src="logo/lo.png" width="40%" height="40%" title="Panel" /> -->
                        
                        </a>
                        
                    </li>  
                  
                    <li>
                        <a href="#"><i class="fa fa-desktop"></i>Registro<span class="fa arrow"></span></a>
                           <ul class="nav nav-second-level">
                            <li>
                                <a href="nuevo_cliente.php">Cliente</a>
                            </li>
                             <li>
                                <a href="nuevo_mascota.php">Asignar Mascotas</a>
                            </li>
                           
                          
                        
                         
                        </ul>
                    </li>
                   
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i> Citas<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                              <li>
                                <a href="nuevo_cita.php"> Nueva Cita</a>
                            </li>
                          </ul>
                    </li>     
                    
					
                    
                    
                    <li>
                        <a href="#"><i class="fa fa-qrcode"></i> Mantenimiento de Usuarios <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Usuario Nuevo</a>
                            </li>
                            <li>
                                <a href="lista_usuarios.php">Lista Usuarios</a>
                            </li>
                          </ul>
                    </li>
                    
                       <li>
                        <a href="#"><i class="glyphicon glyphicon-cog"></i> Configurar<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="confiperfil.php">Perfil</a>
                            </li>
                        </ul>
                    </li>

                </ul>
              
            </div>

        </nav>