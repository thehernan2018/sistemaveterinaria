    
<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="panel.php">
                          <i class="fa fa-dashboard"></i> Panel
                       <!-- <img src="logo/lo.png" width="40%" height="40%" title="Panel" /> -->
                        
                        </a>
                        
                    </li>  
                  
                    <li>
                        <a href="#"><i class="fa fa-desktop"></i>Registro<span class="fa arrow"></span></a>
                           <ul class="nav nav-second-level">
                            <li>
                                <a href="nuevo_cliente.php">Cliente</a>
                            </li>
                            <li>
                                <a href="nuevo_producto.php">Nuevo Producto</a>
                            </li> 
                            <li>
                                <a href="nueva_unidadmedida.php">Nueva Unidad de Medida</a>
                            </li>
                        
                         
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-desktop"></i>Ventas<span class="fa arrow"></span></a>
                           <ul class="nav nav-second-level">
                            <li>
                                <a href="Nuevaventa.php"><span class="glyphicon glyphicon-tag" aria-hidden="true"> Producto</span></a>
                            </li>
                           
                        
                         
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i> Listados<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                               <li>
                                <a href="lista_productos.php">Lista Producos</a>
                            </li>
                             <li>
                                <a href="lista_apoderados.php">Lista Apoderado</a>
                            </li>
                             <li>
                                <a href="lista_alumatricula.php">Lista Alumnos Matriculados</a>
                            </li>
                          </ul>
                    </li>     
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i> Reportes<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                                <li>
                                <a href="reportetotalfinal.php">Reporte total</a>
                            </li>
                             <li>
                                <a href="lista_apoderados.php">Lista Apoderado</a>
                            </li>
                             <li>
                                <a href="lista_alumatricula.php">Lista Alumnos Matriculados</a>
                            </li>
                          </ul>
                    </li>
					<li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i> Pagos<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="matricula.php">Matricula</a>
                            </li>
                             <li>
                                <a href="pagopension.php">Pensión</a>
                            </li>
                            <li>
                                <a href="#">Otros Pagos</a>
                            </li>
                          </ul>
                    </li>
                    
                    
                    <li>
                        <a href="#"><i class="fa fa-qrcode"></i> Mantenimiento de Usuarios <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Usuario Nuevo</a>
                            </li>
                            <li>
                                <a href="lista_usuarios.php">Lista Usuarios</a>
                            </li>
                          </ul>
                    </li>
                    
                       <li>
                        <a href="#"><i class="glyphicon glyphicon-cog"></i> Configurar<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="confiperfil.php">Perfil</a>
                            </li>
                        </ul>
                    </li>

                </ul>
              
            </div>

        </nav>