<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of mascotadao
 *
 * @author HERNAN
 */
class mascotadao implements PHPInterface{
    public function actualizar($objeto) {
        
    }

    public function eliminar($id) {
        
    }

    public function insertar($objeto) {
        
    }

    public function select() {
        
    }

    public function selectid($id) {
        
    }

//put your code here
}
