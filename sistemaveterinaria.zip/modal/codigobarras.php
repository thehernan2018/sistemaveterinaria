
<!--<img src="barcode.php?text=<?php echo $producto->getCodigo(); ?>&size=50&orientation=horizontal&codetype=Code39&print=true&sizefactor=1" />